# ETL Studio UI Plugin Pattern

## Amaç
Airflow Admin altında ETL Studio UI sunmak.

## Beklenen Özellikler
- Şema keşfi
- Tablo keşfi
- YAML üretimi / güncellemesi
- SQL dosya yönetimi
- Tag yönetimi
- Timeline görünümü

## Kısıt
UI layer her iki sürümde ortaktır. Enterprise özellikleri UI'da görünse bile runtime desteği scope'a göre kontrol edilmelidir.
