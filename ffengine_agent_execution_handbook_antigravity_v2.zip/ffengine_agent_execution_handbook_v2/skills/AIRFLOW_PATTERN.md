# Airflow Pattern

## 3 Fazlı DAG Pattern
1. `plan_partitions`
2. `prepare_target`
3. `run_partition.expand()`

## Operator Kuralı
`FFEngineOperator` yalnızca `BaseEngine` kontratını bilir. Engine detect/fallback mekanizması operatör seviyesinde şeffaf çalışmalıdır.

## XCom Anahtarları
- `rows_transferred`
- `duration_seconds`
- `rows_per_second`
