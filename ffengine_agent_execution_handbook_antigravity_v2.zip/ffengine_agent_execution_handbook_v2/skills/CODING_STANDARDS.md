# Coding Standards

## Genel
- Python 3.12 tip ipuçları zorunlu
- Docstring kısa ve somut
- Side-effect içeren yardımcılar açık isimlendirilir
- Magic number kullanma; config veya sabit olarak çıkar

## Mimari
- Interface önce gelir, implementasyon sonra
- Ortak katmanlarda Community/Enterprise özel branch'leri gömülü tutulmaz
- Scope dışı iş için placeholder veya `NotImplementedError` kullan

## Kalite
- Her public sınıf/metod için test yaz
- Lint, type-check ve test geçmeden handoff üretme
