# CONTEXT: C01 — Proje İskeleti & Altyapı

## Amaç
FFEngine Python projesinin temel iskeletini, paket yönetimini, docker ortamını ve CI düzenini kur.

## Çıktılar
- `pyproject.toml`
- `src/ffengine/__init__.py`
- `docker/Dockerfile`
- `docker/docker-compose.yml`
- `.github/workflows/ci.yml`
- `tests/conftest.py`

## Kabul Kriterleri
- `pip install -e .` çalışır
- `import ffengine` hata vermez
- Temel test ve lint pipeline ayağa kalkar
