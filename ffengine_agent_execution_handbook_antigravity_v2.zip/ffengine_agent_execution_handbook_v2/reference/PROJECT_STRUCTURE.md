# Project Structure

```text
ffengine/
├── GEMINI.md
├── AGENTS.md
├── src/
│   └── ffengine/
│       ├── core/
│       ├── db/
│       ├── dialects/
│       ├── engine/
│       ├── airflow/
│       ├── config/
│       ├── mapping/
│       ├── partition/
│       ├── logging/
│       ├── errors/
│       ├── tools/
│       └── ui/
├── tests/
│   ├── unit/
│   └── integration/
├── docs/
├── docker/
├── projects/
│   └── {project}/{domain}/{level}/...
├── skills/
├── context/
├── reference/
└── wbs/
```

## Kural
- Doküman klasörleri (`skills`, `context`, `reference`, `wbs`) kaynak koddan ayrı tutulur.
- `projects/` altındaki YAML, SQL ve mapping çıktıları runtime artefact kabul edilir.
- Enterprise modülleri Community modüllerini override etmez; yalnızca engine detect/fallback zincirine eklenir.
