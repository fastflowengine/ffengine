# Review Prompt

Aşağıdaki checklist her teslimde uygulanır.

## Checklist
1. Scope doğru mu? Community / Enterprise karışmış mı?
2. API imzaları `reference/API_CONTRACTS.md` ile aynı mı?
3. Config davranışı `reference/CONFIG_SCHEMA.md` ile uyumlu mu?
4. Delivery semantics kararı `reference/DELIVERY_GUARANTEE_MATRIX.md` ile uyumlu mu?
5. Hata sınıfları `reference/EXCEPTION_MODEL.md` ile uyumlu mu?
6. Log alanları `reference/LOGGING_SCHEMA.md` ile uyumlu mu?
7. Gerekli workflow kullanılmış mı?
8. Testler yazılmış ve gate testleri geçmiş mi?
9. Scope dışı teknoloji yanlışlıkla implemente edilmiş mi?
10. Handoff hazırlanmış mı?
