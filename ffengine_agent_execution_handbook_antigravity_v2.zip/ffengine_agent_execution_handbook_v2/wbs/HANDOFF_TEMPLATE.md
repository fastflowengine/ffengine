# Handoff Template

```markdown
# HANDOFF: {EPIC_ID} — {EPIC_NAME}

**Tarih:** {YYYY-MM-DD}
**Wave:** {N}
**Durum:** COMPLETE / PARTIAL

## Değişen Dosyalar
| Dosya | İşlem | Açıklama |
|---|---|---|

## Tamamlanan Kabul Kriterleri
- ...

## Açık Riskler
- ...

## Sonraki Wave İçin Notlar
- ...
```
